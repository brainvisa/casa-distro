# -*- coding: utf-8 -*-
from .pure_python import PurePythonComponentBuild as pure_python